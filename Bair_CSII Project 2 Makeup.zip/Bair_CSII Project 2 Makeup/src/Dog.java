// Dog.java
// Dog.java
public class Dog implements PetActions {
    String name;
    int energy;
    int happiness;

    public Dog(String name) {
        this.name = name;
        this.energy = 5;
        this.happiness = 5;
    }

    public void feed() {
        energy += 2;
        happiness += 1;
        System.out.println(name + " the dog has been fed. Energy: " + energy + ", Happiness: " + happiness);
    }

    public void play() {
        energy -= 1;
        happiness += 2;
        System.out.println(name + " is playing fetch! Energy: " + energy + ", Happiness: " + happiness);
    }
}
