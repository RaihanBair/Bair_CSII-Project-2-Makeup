// Main.java
public class Main { // theme: pets and caretaking of pets ||| Ack: https://cs50.ai/chat - This is
    // a coding duck who DOESN'T give code, but helps to edit it. It helped me with the implementing petactions
    // I also used our last project 2 requirements since I figured out the implementation part with the help of coding duck
    public static void main(String[] args) {
        Dog Dog = new Dog("Buddy");
        Cat Cat = new Cat("Whiskers");

        Dog.feed();
        Dog.play();

        Cat.feed();
        Cat.play();
    }
}
