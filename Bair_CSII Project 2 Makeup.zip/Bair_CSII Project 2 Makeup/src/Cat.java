// Cat.java
public class Cat implements PetActions {
    String name;
    int energy;
    int happiness;

    public Cat(String name) {
        this.name = name;
        this.energy = 5;
        this.happiness = 5;
    }

    public void feed() {
        energy += 3;
        happiness += 1;
        System.out.println(name + " the cat has been fed. Energy: " + energy + ", Happiness: " + happiness);
    }

    public void play() {
        energy -= 2;
        happiness += 3;
        System.out.println(name + " is playing with a ball of yarn! Energy: " + energy + ", Happiness: " + happiness);
    }
}

