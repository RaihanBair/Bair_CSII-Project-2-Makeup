// PetActions.java
public interface PetActions {
    void feed();
    void play();
}

